#import <UIKit/UIKit.h>
#import "GPUImageOpenGLESContext.h"

@interface GPUImageView : UIView <GPUImageInput>

@end
